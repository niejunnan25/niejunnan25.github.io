# Event2Reward data formats and examples

Input formats, processing-tool documentation, and original synthetic examples for
[Event2Reward](https://github.com/niejunnan25/Event2Reward), version 0.2.0.
**This package does not contain the full event-annotated training dataset.**

| Included | Purpose |
|---|---|
| [Observation schema](schemas/observations.schema.json) | Task text, episode start, independent successful goal, and five causal history images |
| [Synthetic example](examples/synthetic-inference/observations.json) | Eight queries with geometric images and a separately drawn goal reference |
| [Data formats](docs/formats.md) | Inference observations, relation records, supervision masks, and adaptation manifests |
| [Processing tools](docs/tools.md) | Generate synthetic training data, relocate media paths, materialize portable indices, and inspect splits |

## Try the input format

Follow the [Conda + pip installation guide](https://github.com/niejunnan25/Event2Reward/blob/main/docs/installation.md),
then run from this package's root directory:

```bash
event2reward infer --bundle niejunnan25/Event2Reward-Qwen3.5-4B-Stage2 \
  --observations examples/synthetic-inference/observations.json \
  --output synthetic-progress.json --device cuda:0
```

Model repositories are private during release preparation; loading from the Hub
requires access. A complete local model directory can also be passed to `--bundle`.
The geometric images illustrate input wiring; they are not a robot benchmark and
do not have expected model scores. See their [provenance](examples/synthetic-inference/provenance.json).

For an executable synthetic adaptation example, use the generator in the code repository:

```bash
python -m event2reward.example_data --output data/synthetic
```

Continue with the [adaptation guide](https://github.com/niejunnan25/Event2Reward/blob/main/docs/adaptation.md).
The processing implementations live in the code repository, rather than in this data package.

## Scope and terms

The event annotations, training/validation/test splits and source-media
references used in the paper are coming soon. Source robot videos, private
human-video data and the original annotation-production pipeline are not
included. The four LIBERO demonstrations ship with the code repository examples.

The original schema, documentation, and synthetic images use [Apache-2.0](LICENSE);
see [NOTICE](NOTICE). Third-party datasets and models retain their own terms.
