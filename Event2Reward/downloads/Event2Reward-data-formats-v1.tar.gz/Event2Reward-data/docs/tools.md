# Processing tools

Install [Event2Reward](https://github.com/niejunnan25/Event2Reward/blob/main/docs/installation.md)
to use these commands. This package contains formats and samples; the executable
implementations are in the code repository.

## Generate a synthetic adaptation dataset

```bash
python -m event2reward.example_data --output data/synthetic
```

The generator produces synthetic videos, expert/event relation indices, and a
dataset manifest. Follow the
[adaptation recipe](https://github.com/niejunnan25/Event2Reward/blob/main/docs/adaptation.md)
to prepare a configuration, check it, and run training. These generated data test
the workflow; they do not measure reward quality on real robot tasks.

## Materialize portable indices

```bash
event2reward-data materialize --index portable.jsonl.gz --asset-map local-assets.json --output materialized.jsonl
event2reward-data materialize-set --help
```

Portable indices reference `asset://` IDs. Supply an asset map that resolves them
to locally available media. `materialize-set` handles a collection of indices;
its help documents the manifest format. These tools do not download licensed
source videos. Preserve source identifiers and split assignments.

## Inspect dataset splits

```bash
event2reward-data inspect-splits --indices train.jsonl val.jsonl test.jsonl --output splits.json
```

The checker examines declared physical episode identities and goal-source
splits. It reports missing identity evidence. Different IDs do not prove that
video content is different; the check is not content-based deduplication.

## Relocate existing media paths

```bash
event2reward-train rebase-index --input original.jsonl --output relocated.jsonl --mapping paths.json
```

`paths.json` maps each old media root to a new absolute root. The command relocates
recognized absolute media paths without changing labels or task text. Existing
outputs are protected from overwriting. These are data handling tools, not the
complete original annotation-production pipeline.
