# Data formats

## Inference observations

The CLI accepts a JSON array of observations. Each observation has these fields:

| Field | Meaning |
|---|---|
| `task` | Nonempty task instruction |
| `start` | Episode-start RGB image path |
| `goal` | Independent successful reference image for the same task |
| `history` | Exactly five causal RGB image paths, oldest first, ending at the query |

Paths are relative to the observation JSON file. Use an independent successful
execution for `goal`, never the evaluated trajectory's last frame. Repeat the
start frame where an early query has fewer than five history frames.
Stage2 and the four LIBERO models use 0.1-second history intervals; Stage1 uses
0.25 seconds. The synthetic images illustrate ordering without asserting a
real-world capture rate.

```json
[
  {
    "task": "move the red block into the outlined target on the right",
    "start": "frame-00.png",
    "goal": "goal-reference.png",
    "history": ["frame-00.png", "frame-01.png", "frame-02.png", "frame-03.png", "frame-04.png"]
  }
]
```

This row appears in the [complete eight-query example](../examples/synthetic-inference/observations.json).
The [JSON schema](../schemas/observations.schema.json) checks structure. Temporal
causality, task agreement, and success of the reference require separate checks.
The returned progress is in [0, 1], may decrease, and is not a success probability.
Trend is an auxiliary output.

## Relation records for adaptation

Each JSONL row contains `clips` and an optional `relation`. A clip identifies
`sample_id`, `dataset_id`, `physical_episode_id`, task `instruction`, `video_path`,
`start_frame`, `goal_frame`, five `history_frames`, `current_frame`, and its
supervision masks. Independent goals use `goal_dataset_id` and `goal_video_path`.
`target_progress` is in [0,1]; `progress_valid` controls absolute progress
supervision. `target_trend` is 0/1/2 (growth/stable/regression), with a separate
`trend_valid` mask. A missing absolute label must not be treated as progress zero.

A relation specifies `kind`, `anchor_index`, `secondary_anchor_index` when needed,
`member_indices`, and `margin`:

| Kind | Relation |
|---|---|
| 3 | Recoverable event: no higher than its anchor |
| 4 | Irrecoverable event: strictly below its anchor |
| 5 | Hesitation plateau |
| 6 | Regression valley between two anchors |

Preserve the annotation's anchor semantics and uncertain boundaries. Source
annotations are not universally human-verified. The code's
[executable schema](https://github.com/niejunnan25/Event2Reward/blob/main/event2reward/data/schema.py)
and [loss definitions](https://github.com/niejunnan25/Event2Reward/blob/main/event2reward/modeling/losses.py)
define the precise inequalities.

## Dataset manifest

The adaptation manifest assigns expert and event sources to the training and
validation splits. Generate a complete runnable manifest and records using
`python -m event2reward.example_data --output data/synthetic`.
See the [adaptation guide](https://github.com/niejunnan25/Event2Reward/blob/main/docs/adaptation.md)
for the manifest layout, source fractions, initialization, and supervision masks.
Full source datasets and annotations are not included in this package.
